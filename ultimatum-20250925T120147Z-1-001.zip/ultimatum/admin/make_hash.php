<?php
// Run this file in your browser to get a password hash for 'admin123'
echo password_hash('admin123', PASSWORD_DEFAULT); 